//
//  GirisViewModel.swift
//  FarmingApp
//
//  Created by Talha Gergin on 16.11.2023.
//

import Foundation
class GirisViewModel {
    
}
