//
//  AyarlarViewModel.swift
//  FarmingApp
//
//  Created by Talha Gergin on 17.11.2023.
//

import Foundation
class AyarlarViewModel{
    
}
