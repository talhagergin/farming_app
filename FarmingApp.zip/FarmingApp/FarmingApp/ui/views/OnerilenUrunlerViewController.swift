//
//  OnerilenUrunlerViewController.swift
//  FarmingApp
//
//  Created by Talha Gergin on 14.11.2023.
//

import UIKit

class OnerilenUrunlerViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    

}
