//
//  UrunlerHucreCollectionViewCell.swift
//  FarmingApp
//
//  Created by Talha Gergin on 14.11.2023.
//

import UIKit

class UrunlerHucreCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var labelFiyat: UILabel!
    @IBOutlet weak var labelUrunAd: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    

}
