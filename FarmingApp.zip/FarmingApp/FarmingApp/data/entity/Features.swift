//
//  Features.swift
//  FarmingApp
//
//  Created by Talha Gergin on 14.11.2023.
//

import Foundation
class Features{
    var feature_id:String?
    var product_id:Int?
    var city_id:Int?
    var time_to_water:Int?
    
    
    
}
