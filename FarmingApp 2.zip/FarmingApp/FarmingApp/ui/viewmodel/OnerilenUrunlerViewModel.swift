//
//  OnerilenUrunViewModel.swift
//  FarmingApp
//
//  Created by Talha Gergin on 14.11.2023.
//

import Foundation
import RxSwift
class OnerilenUrunlerViewModel{
    
    var recrepo = RecommendationsDaoRepository()
    var recommendations: [String] = []
    
    func getRecommendations(city: String, avgRainfall: Int, avgTemperature: Int, completion: @escaping () -> Void) {
          recrepo.getRecommendations(city: city, avgRainfall: avgRainfall, avgTemperature: avgTemperature) { [weak self] recommendations in
              guard let self = self else { return }
              self.recommendations = recommendations
              completion() // Parametre eklenmedi
          }
      }
    
}
