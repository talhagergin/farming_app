//
//  GenelBigilerViewModel.swift
//  FarmingApp
//
//  Created by Talha Gergin on 14.11.2023.
//

import Foundation
import RxSwift

class GenelBilgilerViewModel{
    var regionRepo = UrunlerDaoRepository()
    var regionList = BehaviorSubject<[Regions]>(value: [Regions]())
    
    init(){
        regionList = regionRepo.regionList
        getRegions()
        
    }
    func getRegions(){
        regionRepo.getRegions()
    }
    func getCities(regionName:String){
        regionRepo.getCities(regionName:regionName)
    }
}
