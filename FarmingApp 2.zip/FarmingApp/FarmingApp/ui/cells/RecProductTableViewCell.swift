//
//  RecProductTableViewCell.swift
//  FarmingApp
//
//  Created by Talha Gergin on 27.12.2023.
//

import UIKit

class RecProductTableViewCell: UITableViewCell {

    @IBOutlet weak var productNameLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
