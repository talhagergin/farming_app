//
//  OnerilenUrunlerViewController.swift
//  FarmingApp
//
//  Created by Talha Gergin on 14.11.2023.
//

import UIKit
import RxSwift

class OnerilenUrunlerViewController: UIViewController {

    @IBOutlet weak var productTableView: UITableView!
    
    var productList = [RecommendationProducts]()
    var featureList = [Features]()
    let recViewModel = OnerilenUrunlerViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        productTableView.delegate = self
        productTableView.dataSource = self
        fetchData()
    }
    
    func fetchData() {
        recViewModel.getRecommendations(city: "ANKARA", avgRainfall: 20, avgTemperature: 20) {
                DispatchQueue.main.async {
                    self.productTableView.reloadData()
                }
            }
        }

}

extension OnerilenUrunlerViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var count = recViewModel.recommendations.count
        if count > 10 {
            count = 10
        }
        return count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = productTableView.dequeueReusableCell(withIdentifier: "recProductCell") as! RecProductTableViewCell
        //cell.productNameLabel.text = "Elma"
        print("api table view yeri\(recViewModel.recommendations)")
        cell.productNameLabel.text = recViewModel.recommendations[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let product = recViewModel.recommendations[indexPath.row]
        performSegue(withIdentifier: "toDetails", sender: product)
        tableView.deselectRow(at: indexPath, animated: true)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toDetails"{
            if let features = sender as? Features{
                let toVC = segue.destination as! SecilenUrunDetayViewController
                toVC.features = features
            }
        }
    }
    
}
