//
//  SecilenUrunDetayViewController.swift
//  FarmingApp
//
//  Created by Talha Gergin on 14.11.2023.
//

import UIKit

class SecilenUrunDetayViewController: UIViewController {

    @IBOutlet weak var TfWaterAmount: UITextField!
    @IBOutlet weak var TfHasat: UITextField!
    @IBOutlet weak var TfEkilme: UITextField!
    @IBOutlet weak var TfHavalandırma: UITextField!
    @IBOutlet weak var TfGubreleme: UITextField!
    @IBOutlet weak var TfSulama: UITextField!
    
    var product = [Features]()
    var viewModel = SecilenUrunDetayViewModel()
    var features:Features?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        _ = viewModel.productList.subscribe(onNext: {liste in
            self.product = liste
        })
        setToTextField()
    }
    

    func setToTextField(){
        if let prod = features{
            TfHasat.text = prod.hasatZaman
            TfEkilme.text = prod.ekilmeZaman
            TfSulama.text = prod.sulamaZaman
            TfGubreleme.text = prod.gubrelemeZaman
            TfHavalandırma.text = prod.havalandirmaZaman
            TfWaterAmount.text = "\(prod.waterAmount!)"
        }
    }

}
