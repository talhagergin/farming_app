//
//  BeforeStartAnalizViewController.swift
//  FarmingApp
//
//  Created by Talha Gergin on 14.12.2023.
//

import UIKit

class BeforeStartAnalizViewController: UIViewController {

    @IBOutlet weak var startAction: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        startAction.addTarget(self, action: #selector(btnStartAnalysis), for: .touchUpInside)

    }
    

 
    @IBAction func btnStartAnalysis(_ sender: UIButton) {
        animateButtonTap { [weak self] in
                   // Animasyon tamamlandığında yeni bir sayfaya geçiş
            print("animasyon bitti")
            //self?.navigateToNextPage()
               }
    }
    
    func animateButtonTap(completion: @escaping () -> Void) {
        // Ekranda kararma efekti için bir UIView ekleyin
               let dimView = UIView(frame: view.bounds)
               dimView.backgroundColor = UIColor.black
               dimView.alpha = 0.0
               view.addSubview(dimView)

               // Kararma animasyonu
               UIView.animate(withDuration: 0.5, animations: {
                   dimView.alpha = 0.7
               }) { (finished) in
                   UIView.animate(withDuration: 0.5, animations: {
                       dimView.alpha = 0.0
                   }) { (finished) in
                       // Animasyon tamamlandığında kararma görünümünü kaldırın
                       dimView.removeFromSuperview()

                       // Diğer animasyonlar veya işlemleri tamamlayın
                       completion()
                   }
               }
    }

    
}
