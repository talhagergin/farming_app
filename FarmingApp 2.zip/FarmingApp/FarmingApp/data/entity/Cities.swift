//
//  Cities.swift
//  FarmingApp
//
//  Created by Talha Gergin on 18.12.2023.
//

import Foundation
class Cities{
    var cityID:String?
    var cityName:String?
    var regionID:String?
    var regionName:String?
    
    init(){
        
    }
    
    init(cityID: String? = nil, cityName: String? = nil, regionID: String? = nil,regionName: String? = nil) {
        self.cityID = cityID
        self.cityName = cityName
        self.regionID = regionID
        self.regionName = regionName
    }
}

