//
//  Features.swift
//  FarmingApp
//
//  Created by Talha Gergin on 14.11.2023.
//

import Foundation
class Features{
    var feature_id:String?
    var product_id:String?
    var city_id:String?
    var waterAmount:Int?
    var havalandirmaZaman:String?
    var ekilmeZaman:String?
    var sulamaZaman:String?
    var gubrelemeZaman:String?
    var hasatZaman:String?
    
    init(){
        
    }
    
    init(feature_id: String? = nil, product_id: String? = nil, city_id: String? = nil, waterAmount: Int? = nil, havalandirmaZaman: String? = nil, ekilmeZaman: String? = nil, sulamaZaman: String? = nil, gubrelemeZaman: String? = nil, hasatZaman: String? = nil) {
        self.feature_id = feature_id
        self.product_id = product_id
        self.city_id = city_id
        self.waterAmount = waterAmount
        self.havalandirmaZaman = havalandirmaZaman
        self.ekilmeZaman = ekilmeZaman
        self.sulamaZaman = sulamaZaman
        self.gubrelemeZaman = gubrelemeZaman
        self.hasatZaman = hasatZaman
    }
    
    
}
