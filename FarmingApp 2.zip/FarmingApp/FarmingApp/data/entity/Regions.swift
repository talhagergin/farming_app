//
//  Regions.swift
//  FarmingApp
//
//  Created by Talha Gergin on 18.12.2023.
//

import Foundation
class Regions {
    var regionID:String?
    var regionName:String?
    
    init(){
        
    }
    
    init(regionID: String? = nil, regionName: String? = nil) {
        self.regionID = regionID
        self.regionName = regionName
    }
}
