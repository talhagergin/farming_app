//
//  RecommendationProducts.swift
//  FarmingApp
//
//  Created by Talha Gergin on 27.12.2023.
//

import Foundation

class RecommendationProducts{
    var productName:String!
    
    init(productName: String!) {
        self.productName = productName
    }
}
