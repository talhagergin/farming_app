//
//  GetRecommendationsAPI.swift
//  FarmingApp
//
//  Created by Talha Gergin on 27.12.2023.
//

import Foundation

class GetRecommendationsAPI :Codable {
    var recommendatios:[String]
    

    
}
