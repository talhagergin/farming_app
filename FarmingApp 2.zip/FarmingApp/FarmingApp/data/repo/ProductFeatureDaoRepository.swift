//
//  ProductFeatureDaoRepository.swift
//  FarmingApp
//
//  Created by Talha Gergin on 8.01.2024.
//

import Foundation
import FirebaseFirestore
import RxSwift

class ProductFeatureDaoRepository{
    
    var productList = BehaviorSubject<[Features]>(value: [Features]())
    var collectionProductsFeatures = Firestore.firestore().collection("Urunler")
    var cityName:String?
    var productId:String?
    private var listener: ListenerRegistration?
    let db: Firestore
    init() {
        self.db = Firestore.firestore()
        getProducts(productId: productId!)
       
    }
    
    deinit {
        stopListening()
    }
    
    func getProducts(productId: String) {
        let productsFeatureCollection = db.collection("Features")
        let query = productsFeatureCollection.whereField("product_id", isEqualTo: productId)
        
        // Firestore koleksiyonunu dinleme başlat
        
        listener = query.addSnapshotListener { [weak self] (snapshot: QuerySnapshot?, error: Error?) in
            guard let self = self else { return }
            
            if let error = error {
                print("Error getting documents: \(error.localizedDescription)")
                return
            }
          
  
            var list = [Features]()
            let dispatchGroup = DispatchGroup()
            if let documents = snapshot?.documents {
                
                for document in documents {
                    let data = document.data()
                    let id = document.documentID
                    dispatchGroup.enter()
                   
                    self.getCityASDocumentID(documentID: data["city_id"] as! String){cityName in
                        //cityName = cityName
                        let hasatZaman = data["hasatZaman"] as? String ?? ""
                        let ekilmeZaman = data["ekilmeZaman"] as? String ?? ""
                        let gubrelemeZaman = data["gubrelemeZaman"] as? String ?? ""
                        let havalandirmaZaman = data["havalandirmaZaman"] as? String ?? ""
                        let sulamaZaman = data["sulamaZaman"] as? String ?? ""
                        let waterAmount = data["waterAmount"] as? Int ?? 1
                        let feature = Features(feature_id: id,product_id: productId,city_id: cityName,waterAmount:waterAmount,havalandirmaZaman:havalandirmaZaman,ekilmeZaman:ekilmeZaman,sulamaZaman:sulamaZaman,gubrelemeZaman:gubrelemeZaman,hasatZaman:hasatZaman)
                        list.append(feature)
                        dispatchGroup.leave()
                        
                    }
                  
                }
                
            }
               
            dispatchGroup.notify(queue: .main){
                // Observable'a yeni değeri gönder
                self.productList.onNext(list)
            }
          
        }
    }
    
    func stopListening() {
        // Firestore koleksiyonu dinleme sonlandır
        listener?.remove()
    }
    
    func getCityASDocumentID(documentID: String, completion: @escaping (String?) -> Void) {
        let cityCollection = db.collection("Cities")
        let documentRef = cityCollection.document(documentID)

        documentRef.getDocument { (document, error) in
            if let error = error {
                print("Error getting document: \(error.localizedDescription)")
                completion(nil)
                return
            }

            if let document = document, document.exists {
                let data = document.data()
                if let cityName = data?["cityName"] as? String {
                    completion(cityName)
                } else {
                    completion(nil)
                }
            } else {
                print("Document does not exist")
                completion(nil)
            }
        }
    }

}
