//
//  UrunlerDaoRepository.swift
//  FarmingApp
//
//  Created by Talha Gergin on 14.11.2023.
//

import Foundation
import RxSwift
import FirebaseFirestore

class UrunlerDaoRepository{

    var productList = BehaviorSubject<[Urunler]>(value: [Urunler]())
    var regionList = BehaviorSubject<[Regions]>(value: [Regions]())
    var cityList = BehaviorSubject<[Cities]>(value: [Cities]())
    var collectionUrunler = Firestore.firestore().collection("Urunler")
    var collectionRegions = Firestore.firestore().collection("Regions")
    var collectionCities = Firestore.firestore().collection("Cities")
    private var listener: ListenerRegistration?
    let db: Firestore
    init() {
        self.db = Firestore.firestore()
        getProducts()
       
    }
    
    deinit {
        stopListening()
    }
    
    func getProducts() {
        // Firestore koleksiyonunu dinleme başlat
        listener = collectionUrunler.addSnapshotListener { [weak self] (snapshot, error) in
            guard let self = self else { return }
            
            if let error = error {
                print("Error getting documents: \(error.localizedDescription)")
                return
            }
            
            var list = [Urunler]()
            var fiyat: Float = 0.0
            if let documents = snapshot?.documents {
                for document in documents {
                    let data = document.data()
                     let id = document.documentID
                     let urunad = data["product_name"] as? String ?? ""
                    if let priceNumber = data["price"] as? NSNumber {
                        fiyat = Float(truncating: priceNumber)
                    }else{
                        fiyat = 0
                    }
                    
                     let image = data["image"] as? String ?? ""
                     let product_group_id = data["product_group_id"] as? String ?? ""
                     let field_id = data["field_id"] as? String ?? ""
                     let amount_water = data["amount_water"] as? Int ?? 0
                     let created_at = data["created_at"] as? Date ?? Date()
                     let region_id = data["region_id"] as? String ?? ""
                     
                    let urun = Urunler(product_id: id, product_name: urunad,created_at: Date(), field_id: field_id,product_group_id: product_group_id,region_id: region_id,amount_water: amount_water,image: image, price: fiyat)
                     list.append(urun)
                }
            }
            
            // Observable'a yeni değeri gönder
            self.productList.onNext(list)
        }
    }
    
    func stopListening() {
        // Firestore koleksiyonu dinleme sonlandır
        listener?.remove()
    }
    
    func delete(product: Urunler) {
        _ = Firestore.firestore()
        let documentReference = collectionUrunler.document(product.product_id!)
        
        // Firestore'dan belirli bir belgeyi silme
        documentReference.delete { error in
            if let error = error {
                print("Error deleting document: \(error.localizedDescription)")
            } else {
                print("Document successfully deleted!")
            }
        }
    }
    func getRegions() {
    
        // Firestore koleksiyonunu dinleme başlat
        listener = collectionRegions.addSnapshotListener { [weak self] (snapshot, error) in
            guard let self = self else { return }
            
            if let error = error {
                print("Error getting documents: \(error.localizedDescription)")
                return
            }
            
            var list = [Regions]()
            if let documents = snapshot?.documents {
                for document in documents {
                    let data = document.data()
                     let id = document.documentID
                     let regionName = data["regionName"] as? String ?? ""
                     
                    let region = Regions(regionID: id,regionName: regionName)
                    print("1\(regionName)")
                     list.append(region)
                }
            }
            
            // Observable'a yeni değeri gönder
            self.regionList.onNext(list)
            
        }
    }
    
    func getCities(regionName:String) {
        let citiesCollection = db.collection("Cities")
        let query = citiesCollection.whereField("regionName", isEqualTo: regionName)
        
        // Firestore koleksiyonunu dinleme başlat
        listener = query.addSnapshotListener { [weak self] (snapshot, error) in
            guard let self = self else { return }
            
            if let error = error {
                print("Error getting documents: \(error.localizedDescription)")
                return
            }
            
            var list = [Cities]()
            if let documents = snapshot?.documents {
                for document in documents {
                    let data = document.data()
                    let id = document.documentID
                    let cityName = data["cityName"] as? String ?? ""
                    let regionName = data["regionName"] as? String ?? ""
                     
                    let city = Cities(cityID: id,cityName: cityName,regionName: regionName)
                     list.append(city)
                }
            }
            
            // Observable'a yeni değeri gönder
            self.cityList.onNext(list)
        }
    }

}
