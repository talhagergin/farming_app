//
//  RecommendationsDaoRepository.swift
//  FarmingApp
//
//  Created by Talha Gergin on 27.12.2023.
//

import Foundation
import RxSwift
import FirebaseFirestore
import Alamofire

class RecommendationsDaoRepository{
    //var collectionProduct = Firestore.firestore().collection("Urunler")
    
    private var listener: ListenerRegistration?

    func getRecommendations(city: String, avgRainfall: Int, avgTemperature: Int, completion: @escaping ([String]) -> Void) {
            let url = "https://get-recommendations-rbdrxranba-ey.a.run.app"
            let parameters: [String: Any] = [
                "city": city,
                "avg_rainfall": avgRainfall,
                "avg_temperature": avgTemperature
            ]

            AF.request(url, method: .post, parameters: parameters, encoding: JSONEncoding.default).responseJSON { response in
                switch response.result {
                case .success(let value):
                    do {
                        let jsonData = try JSONSerialization.data(withJSONObject: value)
                        let decoder = JSONDecoder()
                        let recommendationResponse = try decoder.decode(RecommendationResponse.self, from: jsonData)
                        completion(recommendationResponse.recommendations)
                        print("\(recommendationResponse)")
                    } catch {
                        print("JSON parsing error: \(error)")
                        completion([])
                    }

                case .failure(let error):
                    print("Alamofire request error: \(error)")
                    completion([])
                    
                }
            }
        }

        struct RecommendationResponse: Decodable {
            let recommendations: [String]
        }
    
    
}
